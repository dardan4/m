﻿namespace WebApplication5.Entity
{
    public class Structure
    {
        public int HotelId { get; set; }
        public int TotalPrice { get; set; }
    }
}
