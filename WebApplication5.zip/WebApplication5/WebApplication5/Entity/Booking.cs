﻿namespace WebApplication5.Entity
{
    public class Booking
    {
        public int Id { get; set; }
        public int HotelId { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime DateEnd { get; set; }
        public int TotalAmount { get; set; }
    }
}
