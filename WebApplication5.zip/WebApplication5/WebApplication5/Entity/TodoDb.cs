﻿using Microsoft.EntityFrameworkCore;
using WebApplication5.Entity;

namespace WebApplication5.Entity
{

    public class TodoDb : DbContext
    {
        public TodoDb(DbContextOptions<TodoDb> options)
        : base(options)
        {
        }

        public DbSet<Users> Users { get; set; }
        public DbSet<Hotels> Hotels { get; set; }
        public DbSet<Booking> Booking { get; set; }
        public DbSet<Admin> Admin { get; set; }

    }

}
