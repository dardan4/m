﻿using System.ComponentModel.DataAnnotations;

namespace WebApplication5.Entity
{
    public class Hotels
    {
        [Key]
        public int HotelId { get; set; }
        public string Content { get; set; }
        public string Title { get; set; }
        public string Price { get; set; }
    }
}
