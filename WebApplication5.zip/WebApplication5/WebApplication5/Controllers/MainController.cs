﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Drawing;
using WebApplication5.Entity;
using WebApplication5.Migrations;

namespace WebApplication5.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MainController : Controller
    {
        private readonly TodoDb _context;

        public MainController(TodoDb context)
        {
            _context = context;
        }
        [HttpPost("/AddUser")]
        public async Task<ActionResult<Users>> AddUser(Users user)
        {
            await _context.Users.AddAsync(user);
            _context.SaveChanges();
            return Ok(user);
        }
        [HttpGet("/GetHotels")]
        public async Task<ActionResult<Users>> GetHotels()
        {
            var data = await _context.Hotels.ToListAsync();


            return Ok(data);
        }
        [HttpPost("/AddBooking")]
        public async Task<ActionResult<Booking>> AddBooking(Booking booking)
        {
            await _context.Booking.AddAsync(booking);
            _context.SaveChanges();
            return Ok(booking);

        }
        [HttpPost("/LoginUser")]
        public async Task<ActionResult<Users>> LoginUser(Users users)
        {

            var data = await _context.Users
                      .Where(e => EF.Functions.Like(e.Email, users.Email) && EF.Functions.Like(e.Password, users.Password))
                      .ToListAsync();
            return Ok(data);

           
        }
        [HttpPost("/LoginAdmin")]
        public async Task<ActionResult<Admin>> LoginAdmin(Admin users)
        {
           var data = await _context.Admin
              .Where(e => EF.Functions.Like(e.Email, users.Email) && EF.Functions.Like(e.Password, users.Password))
              .ToListAsync();
            return Ok(data);
        }
        [HttpPost("/AddHotels")]
        public async Task<ActionResult<Booking>> AddHotels(Hotels hotels)
        {
            await _context.Hotels.AddAsync(hotels);
            _context.SaveChanges();
            return Ok(hotels);

        }
        [HttpGet("/GetIncome")]
        public async Task<ActionResult<Hotels>> GetIncome()
        {
            var query = from c in _context.Hotels
            join o in _context.Booking on c.HotelId equals o.HotelId
            group o by c.HotelId into g
            select new
            {
                HotelId = g.Key,
                                                                                                                           
                Sum = g.Sum(o => o.TotalAmount)
            };
            var query2 = from c in query
            join o in _context.Hotels on c.HotelId equals o.HotelId
            select new
            {
                HotelName=o.Title,
                Sum1 = c.Sum
            };
           return Ok(query2);
        }
        [HttpGet("/GetBooking")]
        public async Task<ActionResult<Booking>> GetBooking(int id)
        {
            var data = await _context.Booking.Join(_context.Hotels,
            ai => ai.HotelId,
           al => al.HotelId, (ai, al)
           => new
           {
               Price = al.Price,
               DateStart = ai.DateStart.ToString("MMMM dd, yyyy"),
               DateEnd = ai.DateEnd.ToString("MMMM dd, yyyy"),
               HotelName = al.Title,
               TotalAmount = ai.TotalAmount,
               Id= ai.Id

           }
           ).Where(s => s.Id ==id ).ToListAsync();
            return Ok(data);
        }
        [HttpGet("/GetIncomeHotel")]
        public async Task<ActionResult<Users>> GetIncomeHotel( int HotelId)
        {
            var data = await _context.Booking.

                Join(_context.Hotels,
            ai => ai.HotelId,
           al => al.HotelId, (ai, al)
           => new
           {
               Price = al.Price,
               HotelId = al.HotelId,
               DateStart = ai.DateStart,
               DateEnd = ai.DateEnd,
               
           }
           ).OrderByDescending(s => s.HotelId).ToListAsync();
           
            var tot = 0;
            Structure st;
            List<Structure> listStructure = new List<Structure>();
           
            for (var i = 0; i < data.Count; i++)
            {
                var Sum1 = 0;
                var diff = (data[i].DateEnd - data[i].DateStart).TotalDays;
                tot = (int)(Int32.Parse(data[i].Price) * diff);
                Sum1 = (int)(tot)+Sum1;
                st = new Structure
                {
                   HotelId = data[i].HotelId,
                   TotalPrice = Sum1
                };
                listStructure.Add(st);
                
            }
            HotelId = 2;
            var sum2 = 0;
            foreach(var list in listStructure)
            {
                if(list.HotelId == HotelId)
                {
                    sum2 = sum2 + list.TotalPrice;
                }
            }
            return Ok(sum2);
        }
    }
}
