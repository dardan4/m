﻿namespace WebApplication5.NewFolder
{
    public class Calculations
    {
       
    }
}
